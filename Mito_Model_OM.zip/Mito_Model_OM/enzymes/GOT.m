function J_GOT=GOT(ASPm,aKGm,GLUm,OXAm,pH_m,p)
% Reaction 9: Glutamate oxaloacetate transaminase (GOT)- Enzyme 
% ASPm +AKGm ⇌ GLUm + OXAm 	

%%% Thermodynamics 
dGr0= -1.31; % kJ/mol Gibbs free energy of the reaction at pH=7 [Li etal 2011]
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0;

%%% Assign Km parameters (Zhang 2018)
KA=3.9e-3;  % M Asparate % xiao comment use jason's parameters
KB=430e-6;   % M alpha-ketoglutrate 
KC=8.9e-3;   % M Glutamate 
KD=88e-6;    % M Oxaloacetate 

%%% Assign conct
A=ASPm;
B=aKGm;
C=GLUm;
D=OXAm;

%%% Flux
deno=(1+A/KA)*(1+B/KB)*(1+C/KC)*(1+D/KD);
J_GOT =1/KA/KB*(A*B-C*D/Keq)/deno; % .3
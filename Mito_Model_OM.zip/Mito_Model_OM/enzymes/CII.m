function J_CII=CII(SUCm,UQm,FUMm,UQH2m,OXAm,MALm,pH_m,p)
% Reaction 11: Complex II-Succinate Dehydrogenase (CII-SDH)
% SUCm + FADm ⇌ FUMm + FADH2m % SDH
% FADH2m + UQm ⇌ FADm + UQH2m % CII
% SUCm + UQm ⇌ FUMm + UQH2m  % Final 

%%% Thermodynamics 
dGr0=-2.41; % kJ/mol Gibbs free energy oreaction at pH=7 [Li etal 2011] 
RT=p.R_con*p.Tem;
Keq0=exp(-dGr0/(RT));
Keq=Keq0; % pH correction 

%%% Assign Km parameters 
KA=1800e-6; % M Succinate
KB=140e-6; % M UQ 
KC=1800e-6; % M Fumarate
KD=2.45e-6; % M UQH2 

%%% Assign conct 
A=SUCm;
B=UQm;
C=FUMm;
D=UQH2m;

%%% CII inhibition 
KOXA=1*.315e-7; % M OXA binding constant
KA=KA*(1+OXAm/KOXA); % V4 inhibition of Suc binding by OXA accumulation 

%%% CII activation 
%%% Redcution in KMAL activates CII
KMAL=1.17e-5; % M Mal binding constant
KA=KA/(1+MALm/KMAL); % V4 activation of CII by MAL

%%% Flux 
deno=(1+A/KA+C/KC)*(1+B/KB+D/KD); % Suc & Fum are redox co-factors
J_CII=1/KA/KB*(A*B-C*D/Keq)/deno; % .5
function J_IDH=IDH(CITm,NADm,aKGm,NADHm,CO2,pH_m,p)
% Reaction 3: Isocitrate dehydrogenase (CITDH)
% CITm +NADm ⇌ AKGm + NADHm +CO2 + 2H

%%% Thermodynamics 
dGr0= 3.29; % kJ/mol Gibbs free energy ot the reaction at pH=7 [Wu etal 2011] % 2.18 Xiao
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(2*(pH_m-7)); 

%%% Assign Km parameters (Zhang 2018)
KA=1.3e-3; % M Citrate
KB=500e-6; % M NAD
KC=3.5e-6; % M alpha-ketoglutrate
KD=4.7e-6; %KD3=1.3e-3; % M NADH (Xiao) %  KD3=4.7e-6; % was changed in the supplement 
KE=1e-5; % M CO2

%%% Assign the conct 
A=CITm;
B=NADm;
C=aKGm;
D=NADHm;
E=CO2;   % CO2 term is constant 

KNADH=1*4.75e-6;  % Jason  et al. Appendix % isnt in the supplement 
NADHi_factor=1*1e3/(1+NADHm/KNADH); % NADH cofactor Xiao

%%% Flux 
deno=(1+A/KA)*(1+C/KC)*(1+B/KB+D/KD);
J_IDH =NADHi_factor/KA/KB*(A*B-C*D*E/Keq)/deno;
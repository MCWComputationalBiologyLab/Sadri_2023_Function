%% declare variables 
% X: state variables;  T: time in min;  J: fuxes;  Pk: peak values of fluxes;  HPk: half the peak values  
% c stands for cell structure; v stand for vector 
addpath('.\enzymes')
load Model_Params % read indexes
load Model_Params_Ht; % read heart params
param=10.^Params_temp; % conversion to linear space 
p.pest(1:p.NPar)=param; p.pest; % estimated Vmax
load Exp_data_Ht;  data = data_HT;
p.org=1; % organ 
p.Algt=1; % algorithm 
p.ISub=1; % initial substrate 
p.NSub=5; % number of substrates  and last substrate
p.NPar=24; % number of parameters
p.NOde=37; % number of ODEs
p.close_system=1; % 1 simulates a closed system like Oroboros, and 0 simulates an open system like PTI
p.Q10_corr=p.Q10_con.^((p.Tem-p.Tem_Stnd)/10); % Xiao p.Tem and p.Tem_Stnd are temps at which reaction rate are measured and calsulated, respectively 
p.tstep = 1/60;   % time step min
p.beta=.35;
p.Ve=.4*20e-3; % mito amount which is .05 mito buffer_Vol/mito_Vol % 20e-3 zhang 
p.time=2*[1, .5, .5, .5, 1, 1, 1.5, 2, 4, 3]'; % 0-1 mito % 1:Sub, 



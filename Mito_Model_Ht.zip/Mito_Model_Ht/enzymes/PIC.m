function T_PiH_C=PIC(Pie,He,Pim,Hm,p)
% Transport 9 - PIC (Inorganic Phosphate Carrier)
% Phosphate-H cotransporter
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% Pie + He+ ⇌ Pim + Hm+

%%% Assign Km parameters (Zhang 2018)
KAm=9.4e-3; % Phosphate binding constant 
KAe=9.4e-3; % Phosphate binding constant 
KB=1e-7; % H+ binding constant 
KC=KAe; KD=KB;

%%% Assign conct
A=Pie;
B=He;
C=Pim;
D=Hm;

%%% Flux
deno=1+A/KAe+B/KB+C/KC+D/KD+C*D/KC/KD+A*B/KB/KAe;
T_PiH_C=1/KB/KAm*(A*B-C*D)/deno;

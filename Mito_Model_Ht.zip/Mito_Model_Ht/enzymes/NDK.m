function J_NDK=NDK(GTPm,ADPm,GDPm,ATPm,pH_m,p)
% Reaction 6: Nucleoside diphosphokinase (NDK)
% GTPm + ADPm ⇌ GDPm + ATPm 	

dGr0= -.56; % kJ/mol (Li 2011)
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0;

%%% Assign Km parameters (Wu 2007)
KA=111e-6; % M GTP
KB=100e-6; % M ADP
KC=260e-6; % M GDP
KD=278e-6; % M ATP

%%% Assign conct 
A=GTPm;
B=ADPm;
C=GDPm;
D=ATPm;

%%% Flux 
deno=(1+A/KA+C/KC)*(1+B/KB+D/KD);
J_NDK=1/KA/KB*(A*B-C*D/Keq)/deno;
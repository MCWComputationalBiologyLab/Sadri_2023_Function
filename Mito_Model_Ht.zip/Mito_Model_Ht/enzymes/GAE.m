function T_ASP_GLU=GAE(GLUe,He,ASPm,ASPe,Hm,GLUm,dPsi,p)
% Transport 7- GAE
% ASP-HGLU Exchanger 
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% HGLUe + ASPm ⇌ HGLUm + ASPe 

%%% Assign Km parameters (Zhang 2018)
KA=0.12e-3; % M Aspartate binding constant
KB=0.25e-3; % M Glutamate binding constant 
KH=1e-7; % M H+ binding constant 
KC=KA;  KD=KB;

%%%% Assign conct
A= ASPm;
B= He*GLUe;
C= ASPe;
D= Hm*GLUm;

RT=p.R_con*p.Tem;
beta_GAE= 0.5; % ASP-GLU transporter free energy barrier

%%% Flux
deno=1+A/KA+B/KB/KH+C/KC+D/KD/KH+A*B/KA/KB/KH+C*D/KC/KD/KH;

T_ASP_GLU=1/KB/KA/KH*(exp(beta_GAE*dPsi.*p.F_con./RT)*B*A-...
    exp((beta_GAE-1)*dPsi.*p.F_con./RT)*C*D)/deno;


function J_CV=CV(ADPm,Pim,ATPm,dGH,pH_m,p)
% Reaction 14: Complex V (CV)
% ADPm + Pim +3Hi + Hm+  ⇌ ATPm + 3Hm+

%%% Thermodynamics 
dGr0=36.03; % kJ/mol Gibbs free energy of the reation at pH=7
RT=p.R_con*p.Tem;
Hm=10^(-pH_m);

betaC5= p.beta;
% betaC5=0.5; % CV free energy barrier

%%% Assign Km parameters (Zhang 2018)
KA=50e-6; % ADP
KB=3e-3; % Pi
KC=50e-6; % ATP

%%% Assign conct 
A=ADPm;
B=Pim;
C=ATPm;

%%% Flux 
% p.nH is 2.66
deno=(1+A/KA+C/KC)*(1+B/KB);
 num=1/KA/KB*(exp(-betaC5*(dGr0-p.nH*dGH-RT*log(Hm/1e-7))/RT)*A*B-...
     exp(-(betaC5-1)*(dGr0-p.nH*dGH-RT*log(Hm/1e-7))/RT)*C);
 J_CV =num/deno;

function T_ANT=ANT(ADPe,ATPm,ADPm,ATPe,dPsi,RT,p)
% Transport 8- Reaction 22 - ANT (Adenine Nucleotide Translocase)
% ATP ADP Anti-transporters
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% ADPe + ATPm ⇌ ADPm + ATPe 

%%% Assign Km parameters 
KA=.8*p.ANT_ft*5.1*10e-6; % M ADP binding constant % modified E metelkin et al
KB=p.ANT_ft*5.7*10e-6; % M ATP binding constant % modified based on E metelkin et al
KC=KA; KD=KB;

%%% Assign conct
A=ADPe;
B=ATPm;
C=ADPm;
D=ATPe;

beta_ANT=0.6; %Sensitivity increases with Beta

%%% Flux
% Shima 
deno=(1+C/KC+B/KB*exp(beta_ANT*p.F_con*dPsi/RT))*(1+A/KA+D/KD*exp((beta_ANT-1)*p.F_con*dPsi/RT));
T_ANT=((exp(beta_ANT*p.F_con*dPsi/RT)*A*B/KA/KB)-(exp((beta_ANT-1)*p.F_con*dPsi/RT)*C*D/KC/KD))/deno;

% Xiao
% deno=(KB22*KA22+KB22*C22+KA22*B22*exp(beta_ANT*p.F_con*dPsi/RT))*...
%     (KB22*KA22+KB22*A22+KA22*D22*exp((beta_ANT-1)*p.F_con*dPsi/RT));
% T_ANT =1*(exp(beta_ANT*dPsi*p.F_con/RT)*A22*B22-exp((beta_ANT-1)*dPsi*p.F_con/RT)*C22*D22)/deno;

% % final for xiao parameters 
% deno=1*1*(1+C22/KA22+B22/KB22*exp(beta_ANT*p.F_con*dPsi/RT))*(1+A22/KA22+D22/KB22*exp((beta_ANT-1)*p.F_con*dPsi/RT));
% T_ANT=(1/KA22/KB22)*((exp(beta_ANT*p.F_con*dPsi/RT)*A22*B22/KA22/KB22)-(exp((beta_ANT-1)*p.F_con*dPsi/RT)*C22*D22/KA22/KB22))/deno;
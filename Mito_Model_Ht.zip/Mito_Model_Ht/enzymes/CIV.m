function J_CIV=CIV(CytCred,O2,CytCoxi,dPsi,dGH,pH_m,p)
% Reaction 14: Complex IV (CIV)
% 2CytCr + 0.5*O2 + 2Hm ⇌ 2CytCo + H2O + 2ΔH	

%%% Thermodynamics 
dGr0=-122.94; % kJ/mol Gibbs free energy of the reation at pH=7
RT=p.R_con*p.Tem;
Hm=10^(-pH_m);

betaC4= p.beta;
% betaC4=0.5; % CIV free energy barrier

%%% Assign Km parameters (Zhang 2018)
KA=680e-6; % M CytCr
KB=5.4e-6; % M O2
KC=79.2e-6; % M CytCo 

%%% Assign conct 
A=CytCred;
B=O2;
C=CytCoxi;

%%% Flux 
deno=(1+A^2/KA^2+C^2/KC^2)*(1+B^0.5/KB^0.5);
num=1/KA^2/KB^.5*(exp(-betaC4*(dGr0+2*dGH+2*p.F_con*dPsi-RT*log(Hm/1e-7))/RT)*A^2*B^.5-...
    exp(-(betaC4-1)*(dGr0+2*dGH+2*p.F_con*dPsi-RT*log(Hm/1e-7))/RT)*C^2);
J_CIV=num/deno;



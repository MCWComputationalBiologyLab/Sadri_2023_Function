function T_PYR_H=PYRH(PYRe,He,PYRm,Hm,p)
% Transport 1 - PYRH
% Pyruvate-Hydrogen co-transporter between e and m
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 
% PYRe + He ⇌ PYRm + Hm	

%%% Assign Km parameters (Zhang 2018)
KA=0.24e-3;    % M pyruvate binding constant
KB=1e-7; % M H+ binding constant 
KC=KA;  KD=KB;

%%% Assign conct
A=PYRe;
B=He;
C=PYRm;
D=Hm;

%%% Flux
deno=1+A/KA+B/KB+C/KC+D/KD+A*B/KB/KA+C*D/KC/KD;
T_PYR_H=1/KA/KB*(A*B-C*D)/deno;

 function T_MAL_HCIT=TCC(MALe,Hm,CITm,MALm,CITe,He,p)
% Transport 5 - TCC
% MAL-HCIT  Antiporter
% Tricarboxylate Carrier (TCC)
% TCC: MALe + HCITm ⇌ MALm	+ HCITe
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 

%%% Assign Km parameters (Zhang 2018)
KA=1e-3;   % M CIT binding constant
KB=0.25e-3;   % M Malate binding constant
KH=1e-7;  % M H+ binding constant 
KC=KA;  KD=KB;

%%% Assign conct
A=Hm*CITm; % HCITm
B=MALe;
C=He*CITe; % HCITe
D=MALm;


%%% Flux
deno=1+A/KA/KH+B/KB+C/KC/KH+D/KD+A*B/KA/KB/KH+C*D/KC/KD/KH;
T_MAL_HCIT=1/KB/KA/KH*(A*B-C*D)/deno;

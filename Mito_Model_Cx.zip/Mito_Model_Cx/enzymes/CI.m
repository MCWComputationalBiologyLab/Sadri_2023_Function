function J_CI=CI(NADHm,UQm,NADm,UQH2m,Pim,pH_m,dGH,p)
% Reaction 10: Complex I (CI)- Enzyme  
% NADHm + UQm + Hm ⇌ NADm + UQH2m + 4ΔH	

%%% Thermodynamics
dGr0=-69.37; % kJ/mol Gibbs free energy of the reaction at pH=7
RT=p.R_con*p.Tem; % 
Hm=10^(-pH_m);

betaC1= p.beta;
% betaC1= .5;
a=1;
%%% Assign Km parameters (Zhang 2018)
KA=a*1.5e-6; % M NADH
KB=a*58.1e-6; % M UQ
KC=428e-6; % M NAD
KD=520e-6; % M UQH2

%%% Assign Conct
A=NADHm;
B=UQm;
C=NADm;
D=UQH2m;

%%% Flux
deno=(1+A/KA+C/KC)*(1+B/KB+D/KD);
num=1/KA/KB*(exp(-betaC1*(dGr0+4*dGH-RT*log(Hm/1e-7))/RT)*A*B-...
    exp(-(betaC1-1)*(dGr0+4*dGH-RT*log(Hm/1e-7))/RT)*C*D);
J_CI=1*num/deno;



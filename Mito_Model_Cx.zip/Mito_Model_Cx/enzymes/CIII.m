function J_CIII=CIII(UQH2m,CytCoxi,UQm,CytCred,dPsi,dGH,pH_m,p)
% Reaction 12: Complex III (CIII)- Enzyme 
% UQH2m + 2CytCo ⇌ UQm + 2CytCr + 2Hm + 4ΔH			

%%% Thermodynamics 
dGr0=-32.53; % kJ/mol Gibbs free energy of the reation at pH=7
RT=p.R_con*p.Tem;
Hm=10^(-pH_m);

betaC3= p.beta;
% betaC3=0.5; % CIII free energy barrier

%%% Assign Km parameters 
KA12=4.66e-6; % M UQH2
KB12=3.76e-6; % M CytCo
KC12=4.08e-6; % M UQ
KD12=4.91e-6; % M CytCr

%%% Assign conct 
A=UQH2m;
B=CytCoxi;
C=UQm;
D=CytCred;

%%% Flux 
deno=(1+A/KA12+C/KC12)*(1+B^2/KB12^2+D^2/KD12^2);
num=1/KA12/(KB12^2)*(exp(-betaC3*(dGr0+4*dGH+2*RT*log(Hm/1e-7)-2*p.F_con*dPsi)/RT)*A*B^2-...
    exp(-(betaC3-1)*(dGr0+4*dGH+2*RT*log(Hm/1e-7)-2*p.F_con*dPsi)/RT)*C*D^2);
J_CIII=1*num/deno;
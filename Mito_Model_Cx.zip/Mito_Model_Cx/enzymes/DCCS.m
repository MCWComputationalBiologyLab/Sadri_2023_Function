function T_SUC_Pi=DCCS(SUCe,Pim,Pie,SUCm,MALe,MALm,FUMm,p)
% Transport 3 - DCC(SUC)
% Dicarboxylate Carrier (DCC)
% DCC (SUC): Pim + SUCe ⇌ Pie + SUCm 	
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 		

%%% Assign Km parameters (Zhang 2018)
KA=1*1e-3; % M Suc binding constant  V2
KB=1*.93e-4;  % 1 M Pi binding constant ref [1] % smaller KB give behavior suc
KC=KA;   KD=KB; 

A=SUCe;
B=Pim;
C=SUCm;
D=Pie;

%%% Inibition of T_Suc_Pi by matrix malate
KMal=.4*4.17e-3;   % M Mal binding constant 
KA=KA*(1+MALm/KMal); % V4 

%%% Flux
deno=1+A/KA+B/KB+C/KC+D/KD+A*B/KA/KB+C*D/KC/KD;
T_SUC_Pi=1/KA/KB*(A*B-C*D)/deno;



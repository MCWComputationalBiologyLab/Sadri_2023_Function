function J_MDH=MDH(MALm,NADm,OXAm,NADHm,pH_m,p)
% Reaction 8: Malate Dehydrogenase (MDH)- Enzyme 
% MALm + NADm ⇌ OXAm + NADHm + Hm+ 			

%%% Thermodynamics 
dGr0= 28.83; % kJ/mol [Li etal 2011]
Keq0=exp(-dGr0/(p.R_con*p.Tem));
Keq=Keq0*10^(pH_m-7); % pH correction 

%%% Assign Km parameters (Zhang 2018)
KA=1*1.55e-4; % M Malate
KB=1.1e-3; % M NAD
KC=3.38e-6; % M oxaloacetate 
KD=3.61e-5; % M NADH

%%% Assign conct
A=MALm;
B=NADm;
C=OXAm;
D=NADHm;

%%% Flux
deno=(1+A/KA+C/KC)*(1+B/KB+D/KD);
J_MDH =1/KA/KB*(A*B-C*D/Keq)/deno;

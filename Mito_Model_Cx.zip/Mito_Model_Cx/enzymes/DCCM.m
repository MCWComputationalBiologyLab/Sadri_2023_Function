function T_MAL_Pi=DCCM(MALe,Pim,Pie,MALm,SUCe,SUCm,p)
% Transport 4 - DCC(MAL)
% Dicarboxylate Carrier (DCC)	
% DCC (MAL): Pim + MALe ⇌ Pie + MALm 	
% e: extra mitochondria region (buffer)
% m: matrix mitochondria region 

%%% Assign Km parameters (Zhang 2018)
KA=1.17e-3;   % 10 M Mal binding constant % larger KA intensify Suc behavior 
KB=0.93e-3;  % M Pi binding constant ref [1]
KD=KB; KC=KA;

A=MALe;
B=Pim;
C=Pie;
D=MALm;

%%% Inhibition of Mal-Pi transporter by matrix Suc
KSuc=100*.057e-3; KA=KA*(1+SUCm/KSuc); % inhibition of Malm binding to Mal-Pi by Sucm

%%% Flux
deno=1+B/KB+A/KA+C/KD+D/KC+B*A/KB/KA+C*D/KD/KC;
T_MAL_Pi=1/KA/KB*(A*B-C*D)/deno;
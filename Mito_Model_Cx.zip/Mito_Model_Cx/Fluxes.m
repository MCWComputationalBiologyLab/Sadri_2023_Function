function ETfluxes=Fluxes(x,p)
Vmaxp=p.ini_VTmax.*p.Q10_corr.*p.pest(1:24); % p.Q10_corr is 1.624
RT=p.R_con*p.Tem;
CO2=1.32e-5;   %henry's law

%% state variables 
%%% Buffer region 
% -- Nucleotides --
ADPe = x(p.iADPe);
ATPe = x(p.iATPe);
% -- Substrates --
Pie  = x(p.iPie); 
PYRe = x(p.iPYRe);
MALe = x(p.iMALe); % 5
CITe = x(p.iCITe);
aKGe = x(p.iaKGe);
SUCe = x(p.iSUCe);
GLUe = x(p.iGLUe);
ASPe = x(p.iASPe); % 10
% -- Ions --
He=x(p.iHe);    pH_e=-log10(He);

%%% Matrix region 
% -- Nucleotides --
ADPm   = x(p.iADPm);
ATPm = x(p.iATPm);
GDPm = x(p.iGDPm);
GTPm = x(p.iGTPm); % 15
% -- respiratory substrates --
NADm  = x(p.iNADm);
NADHm = x(p.iNADHm);
UQm   = x(p.iUQm);
UQH2m =x(p.iUQH2m);
CytCoxi = x(p.iCytCoxi); % 20
CytCred = x(p.iCytCred);
Pim = x(p.iPim);
% -- TCA substrates --
GLUm = x(p.iGLUm);
ASPm = x(p.iASPm);
PYRm = x(p.iPYRm); % 25
OXAm = x(p.iOXAm);
CITm = x(p.iCITm);
aKGm = x(p.iaKGm);
SCAm = x(p.iSCAm);
SUCm = x(p.iSUCm); % 30
FUMm = x(p.iFUMm);
MALm = x(p.iMALm);
COAm= x(p.iCOAm);
ACOAm= x(p.iACOAm);
O2=x(p.iO2m); % 35
if (O2 <= 1e-6)
    O2 = 1e-6;
end
dPsi=x(p.idPsi); % 36
% -- ions --
Hm=x(p.iHm);    pH_m=-log10(Hm); % 37
dGH = (p.F_con*dPsi+ p.R_con*p.Tem*log(He/Hm));

%% enzymes fluxes- 14
%1----------------------------------------------
J_PDH =Vmaxp(p.iPDH)*PDH(PYRm,COAm,NADm,ACOAm,CO2,NADHm,pH_m,p); 
%2----------------------------------------------
J_CITS =Vmaxp(p.iCITS)*CITS(ACOAm,OXAm,COAm,CITm,pH_m,p);
%3----------------------------------------------
J_IDH =Vmaxp(p.iICDH)*IDH(CITm,NADm,aKGm,NADHm,CO2,pH_m,p);
%4----------------------------------------------
J_AKGDH =Vmaxp(p.iAKGDH)*AKGDH(aKGm,COAm,NADm,SCAm,NADHm,CO2,pH_m,p);
%5----------------------------------------------
J_SCAS= Vmaxp(p.iSCAS)*SCAS(SCAm,GDPm,Pim,SUCm,GTPm,COAm,pH_m,p); 
%6----------------------------------------------
J_NDK=Vmaxp(p.iNDK)*NDK(GTPm,ADPm,GDPm,ATPm,pH_m,p);
%7----------------------------------------------
J_FH =Vmaxp(p.iFH)*FH(FUMm,MALm,pH_m,p);
%8----------------------------------------------
J_MDH=Vmaxp(p.iMDH)*MDH(MALm,NADm,OXAm,NADHm,pH_m,p);
%9----------------------------------------------
J_GOT =Vmaxp(p.iGOT)*GOT(ASPm,aKGm,GLUm,OXAm,pH_m,p);
%10----------------------------------------------
J_CI =Vmaxp(p.iCI)*CI(NADHm,UQm,NADm,UQH2m,Pim,pH_m,dGH,p); 
%11----------------------------------------------
J_CII=Vmaxp(p.iCII)*CII(SUCm,UQm,FUMm,UQH2m,OXAm,MALm,pH_m,p);
%12----------------------------------------------
J_CIII=Vmaxp(p.iCIII)*CIII(UQH2m,CytCoxi,UQm,CytCred,dPsi,dGH,pH_m,p);
%13------------------------------------------------
J_CIV =Vmaxp(p.iCIV)*CIV(CytCred,O2,CytCoxi,dPsi,dGH,pH_m,p);
%14----------------------------------------------
J_CV = Vmaxp(p.iCV)*CV(ADPm,Pim,ATPm,dGH,pH_m,p);
a=1; b=1;
Vmax=b.*[a*Vmaxp(p.iPDH),Vmaxp(p.iCITS),Vmaxp(p.iICDH),a*Vmaxp(p.iAKGDH),Vmaxp(p.iSCAS),a*Vmaxp(p.iNDK),Vmaxp(p.iFH),...
    a*Vmaxp(p.iMDH),a*Vmaxp(p.iGOT),Vmaxp(p.iCI),Vmaxp(p.iCII),Vmaxp(p.iCIII),a*Vmaxp(p.iCIV),Vmaxp(p.iCV)];

%% Transporter fluxes- 10
%15----------------------------------------------
T_PYRH=Vmaxp(p.iPYRH)*PYRH(PYRe,He,PYRm,Hm,p);
%16----------------------------------------------------------
T_GLUH=Vmaxp(p.iGLUH)*GLUH(GLUe,He,GLUm,Hm,p);
%17------------------------------------------------
T_DCCS=Vmaxp(p.iDCC1)*DCCS(SUCe,Pim,Pie,SUCm,MALe,MALm,FUMm,p);
%18---------------------------------------------------------------
T_DCCM=Vmaxp(p.iDCC2)*DCCM(MALe,Pim,Pie,MALm,SUCe,SUCm,p);
%19-------------------------------------------------------
T_TCC=Vmaxp(p.iTCC)*TCC(MALe,Hm,CITm,MALm,CITe,He,p);
%20-------------------------------------------------------
T_OME=Vmaxp(p.iOME)*OME(aKGm,MALe,aKGe,MALm,p);
%21-----------------------------------------------------------------
T_GAE=Vmaxp(p.iGAE)*GAE(GLUe,He,ASPm,ASPe,Hm,GLUm,dPsi,p);
%22-------------------------------------------------------------------------
T_ANT =Vmaxp(p.iANT)*ANT(ADPe,ATPm,ADPm,ATPe,dPsi,RT,p);
%23------------------------------------------------------------------------------
T_PIC=Vmaxp(p.iPIC)*PIC(Pie,He,Pim,Hm,p);
%24------------------------------------------------
T_HLEAK=Vmaxp(p.iHLEAK)*HLEAK(He,dPsi,RT,Hm,p);

Tmax=b.*[a*Vmaxp(p.iPYRH),Vmaxp(p.iGLUH),Vmaxp(p.iDCC1),Vmaxp(p.iDCC2),Vmaxp(p.iTCC),Vmaxp(p.iOME),...
    Vmaxp(p.iGAE),Vmaxp(p.iANT),a*Vmaxp(p.iPIC),Vmaxp(p.iHLEAK)];

%% Metabolic reaction and transport fluxes- 24(+TR123)
ETfluxes=[
J_PDH;
J_CITS;
J_IDH;
J_AKGDH;
J_SCAS;
J_NDK; 
J_FH;
J_MDH;
J_GOT; % 9
J_CI;    
J_CII;
J_CIII;
J_CIV;
J_CV;     % 14
T_PYRH;
T_GLUH;
T_DCCS;
T_DCCM;
T_TCC;
T_OME; % OME 20 
T_GAE; % GAE
T_ANT;
T_PIC;
T_HLEAK; % 24
];